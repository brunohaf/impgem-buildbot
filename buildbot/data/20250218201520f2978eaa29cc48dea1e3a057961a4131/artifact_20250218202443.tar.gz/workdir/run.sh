#!/bin/sh
echo hey leleozin >> output.txt && sleep infinity
